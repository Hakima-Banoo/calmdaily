/*
 ╔═══════════════════════════════════════════════════════════╗
 ║           CalmDaily — Backend Server                      ║
 ║   Stripe subscriptions + Firebase Admin verification      ║
 ╚═══════════════════════════════════════════════════════════╝
*/

require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const stripe  = require('stripe')(process.env.STRIPE_SECRET_KEY);
const admin   = require('firebase-admin');

const app = express();

/* ── Firebase Admin initialisation ────────────────────────── */
const serviceAccount = {
  type: 'service_account',
  project_id:                process.env.FIREBASE_PROJECT_ID,
  private_key_id:            process.env.FIREBASE_PRIVATE_KEY_ID,
  private_key:               process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  client_email:              process.env.FIREBASE_CLIENT_EMAIL,
  client_id:                 process.env.FIREBASE_CLIENT_ID,
  auth_uri:                  'https://accounts.google.com/o/oauth2/auth',
  token_uri:                 'https://oauth2.googleapis.com/token',
};

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

/* ── Middleware ────────────────────────────────────────────── */
// Stripe webhook needs raw body — mount BEFORE express.json()
app.post(
  '/webhook',
  express.raw({ type: 'application/json' }),
  handleStripeWebhook
);

app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || '*',
  methods: ['GET', 'POST'],
}));
app.use(express.json());

/* ── Auth middleware ───────────────────────────────────────── */
async function requireAuth(req, res, next) {
  const header = req.headers.authorization || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token provided' });
  try {
    req.user = await admin.auth().verifyIdToken(token);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

/* ══════════════════════════════════════════════════════════
   STRIPE ROUTES
══════════════════════════════════════════════════════════ */

/*  POST /create-checkout-session
    Body: { plan: 'monthly' | 'yearly' }
    Creates a Stripe Checkout session and returns the URL.
*/
app.post('/create-checkout-session', requireAuth, async (req, res) => {
  try {
    const { plan } = req.body;
    const uid      = req.user.uid;
    const email    = req.user.email;

    // Look up or create a Stripe customer tied to this Firebase UID
    const userDoc  = await db.collection('users').doc(uid).get();
    let customerId = userDoc.exists ? userDoc.data().stripeCustomerId : null;

    if (!customerId) {
      const customer = await stripe.customers.create({
        email,
        metadata: { firebaseUID: uid },
      });
      customerId = customer.id;
      await db.collection('users').doc(uid).set(
        { stripeCustomerId: customerId },
        { merge: true }
      );
    }

    const priceId = plan === 'yearly'
      ? process.env.STRIPE_PRICE_YEARLY
      : process.env.STRIPE_PRICE_MONTHLY;

    const session = await stripe.checkout.sessions.create({
      customer:             customerId,
      payment_method_types: ['card'],
      mode:                 'subscription',
      line_items:           [{ price: priceId, quantity: 1 }],
      allow_promotion_codes: true,
      subscription_data: {
        trial_period_days: 7,           // 7-day free trial
        metadata: { firebaseUID: uid },
      },
      success_url: `${process.env.APP_URL}/pages/dashboard.html?upgraded=true`,
      cancel_url:  `${process.env.APP_URL}/pages/dashboard.html?upgraded=false`,
    });

    res.json({ url: session.url });
  } catch (err) {
    console.error('Checkout error:', err);
    res.status(500).json({ error: err.message });
  }
});

/*  POST /create-portal-session
    Opens Stripe Customer Portal so users can cancel/update billing.
*/
app.post('/create-portal-session', requireAuth, async (req, res) => {
  try {
    const uid     = req.user.uid;
    const userDoc = await db.collection('users').doc(uid).get();
    const customerId = userDoc.exists ? userDoc.data().stripeCustomerId : null;
    if (!customerId) return res.status(400).json({ error: 'No subscription found' });

    const session = await stripe.billingPortal.sessions.create({
      customer:   customerId,
      return_url: `${process.env.APP_URL}/pages/dashboard.html`,
    });
    res.json({ url: session.url });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/*  GET /subscription-status
    Returns current plan for the authenticated user.
*/
app.get('/subscription-status', requireAuth, async (req, res) => {
  try {
    const userDoc = await db.collection('users').doc(req.user.uid).get();
    if (!userDoc.exists) return res.json({ plan: 'free' });
    const data = userDoc.data();
    res.json({
      plan:               data.plan || 'free',
      stripeStatus:       data.stripeStatus || null,
      subscriptionEnd:    data.subscriptionEnd || null,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ══════════════════════════════════════════════════════════
   STRIPE WEBHOOK  (keeps Firebase in sync with Stripe)
══════════════════════════════════════════════════════════ */

async function handleStripeWebhook(req, res) {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature error:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  const getUID = async (customerId) => {
    const snap = await db.collection('users')
      .where('stripeCustomerId', '==', customerId)
      .limit(1).get();
    return snap.empty ? null : snap.docs[0].id;
  };

  try {
    switch (event.type) {

      case 'checkout.session.completed': {
        const session    = event.data.object;
        const customerId = session.customer;
        const uid        = session.subscription_data?.metadata?.firebaseUID
                        || await getUID(customerId);
        if (uid) {
          await db.collection('users').doc(uid).set(
            { plan: 'premium', stripeStatus: 'active', stripeCustomerId: customerId },
            { merge: true }
          );
          // Set Firebase custom claim so app reads it instantly
          await admin.auth().setCustomUserClaims(uid, { plan: 'premium' });
        }
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice    = event.data.object;
        const uid        = await getUID(invoice.customer);
        if (uid) {
          await db.collection('users').doc(uid).set(
            { plan: 'premium', stripeStatus: 'active' },
            { merge: true }
          );
          await admin.auth().setCustomUserClaims(uid, { plan: 'premium' });
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object;
        const uid     = await getUID(invoice.customer);
        if (uid) {
          await db.collection('users').doc(uid).set(
            { stripeStatus: 'past_due' },
            { merge: true }
          );
        }
        break;
      }

      case 'customer.subscription.deleted': {
        const sub = event.data.object;
        const uid = await getUID(sub.customer);
        if (uid) {
          await db.collection('users').doc(uid).set(
            { plan: 'free', stripeStatus: 'canceled', subscriptionEnd: new Date().toISOString() },
            { merge: true }
          );
          await admin.auth().setCustomUserClaims(uid, { plan: 'free' });
        }
        break;
      }

      case 'customer.subscription.updated': {
        const sub    = event.data.object;
        const uid    = await getUID(sub.customer);
        const active = ['active', 'trialing'].includes(sub.status);
        if (uid) {
          await db.collection('users').doc(uid).set(
            { plan: active ? 'premium' : 'free', stripeStatus: sub.status },
            { merge: true }
          );
          await admin.auth().setCustomUserClaims(uid, { plan: active ? 'premium' : 'free' });
        }
        break;
      }
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook handler error:', err);
    res.status(500).json({ error: err.message });
  }
}

/* ══════════════════════════════════════════════════════════
   USER DATA ROUTES (save wellness data to Firestore)
══════════════════════════════════════════════════════════ */

/*  POST /save-data
    Body: { data: { ...appData } }
    Saves user's wellness data to Firestore.
*/
app.post('/save-data', requireAuth, async (req, res) => {
  try {
    const { data } = req.body;
    await db.collection('userData').doc(req.user.uid).set(
      { ...data, updatedAt: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/*  GET /get-data
    Returns user's wellness data from Firestore.
*/
app.get('/get-data', requireAuth, async (req, res) => {
  try {
    const doc = await db.collection('userData').doc(req.user.uid).get();
    res.json(doc.exists ? doc.data() : {});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ── Health check ──────────────────────────────────────────── */
app.get('/health', (_, res) => res.json({ status: 'ok', app: 'CalmDaily' }));

/* ── Start server ──────────────────────────────────────────── */
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n🌿 CalmDaily backend running on port ${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV || 'development'}`);
});


/* ══════════════════════════════════════════════════════════
   PUSH NOTIFICATIONS (Firebase Cloud Messaging)
══════════════════════════════════════════════════════════ */

/*  POST /save-fcm-token
    Saves user's push notification token to Firestore.
*/
app.post('/save-fcm-token', requireAuth, async (req, res) => {
  try {
    const { token } = req.body;
    if (!token) return res.status(400).json({ error: 'No token' });
    await db.collection('users').doc(req.user.uid).set(
      { fcmToken: token, fcmUpdated: admin.firestore.FieldValue.serverTimestamp() },
      { merge: true }
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/*  POST /send-notification
    Send a push notification to a specific user (admin use).
    Body: { uid, title, body, url }
*/
app.post('/send-notification', requireAuth, async (req, res) => {
  try {
    const { uid, title, body, url } = req.body;
    const userDoc = await db.collection('users').doc(uid).get();
    const token   = userDoc.data()?.fcmToken;
    if (!token) return res.status(404).json({ error: 'No FCM token for user' });

    const message = {
      token,
      notification: { title, body },
      data: { url: url || '' },
      webpush: {
        notification: { icon: '/calmdaily/icons/icon-192.png', badge: '/calmdaily/icons/icon-72.png' },
        fcmOptions:   { link: url || '/calmdaily/pages/dashboard.html' }
      }
    };

    const result = await admin.messaging().send(message);
    res.json({ success: true, messageId: result });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/*  Scheduled daily reminders — call this from a cron job
    e.g. set up a cron on Render or use a free cron service like cron-job.org
    to call POST /send-daily-reminders every hour
*/
app.post('/send-daily-reminders', async (req, res) => {
  // Simple auth — use a secret key for cron requests
  if (req.headers['x-cron-secret'] !== process.env.CRON_SECRET) {
    return res.status(401).json({ error: 'Unauthorized' });
  }
  try {
    const currentHour = new Date().getUTCHours();
    // Find users whose reminder time matches current hour
    const snap = await db.collection('users')
      .where('reminderHour', '==', currentHour)
      .where('fcmToken', '!=', null)
      .get();

    const messages = snap.docs.map(doc => ({
      token: doc.data().fcmToken,
      notification: {
        title: 'Time for your CalmDaily session 🌿',
        body:  `Hey ${doc.data().name?.split(' ')[0] || 'there'}! Your daily wellness session is waiting.`
      },
      webpush: {
        notification: { icon: '/calmdaily/icons/icon-192.png' },
        fcmOptions:   { link: '/calmdaily/pages/dashboard.html' }
      }
    }));

    if (messages.length === 0) return res.json({ sent: 0 });

    const result = await admin.messaging().sendEach(messages);
    res.json({ sent: result.successCount, failed: result.failureCount });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* ══════════════════════════════════════════════════════════
   WELCOME EMAIL  (via Resend.com — free 3,000 emails/month)
══════════════════════════════════════════════════════════ */

/*  POST /send-welcome-email
    Called after new user signs up.
    Body: { email, name }
    Requires RESEND_API_KEY in .env
*/
app.post('/send-welcome-email', requireAuth, async (req, res) => {
  try {
    const { email, name } = req.body;
    const firstName = (name || 'friend').split(' ')[0];

    if (!process.env.RESEND_API_KEY) {
      console.log('RESEND_API_KEY not set — skipping welcome email');
      return res.json({ success: true, note: 'Email skipped — no Resend key' });
    }

    const emailRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from:    'CalmDaily <support@calmdaily.app>',
        to:      [email],
        subject: `Welcome to CalmDaily, ${firstName} 🌿`,
        html: `
<!DOCTYPE html>
<html>
<head><meta charset="utf-8"/></head>
<body style="background:#0E0E0E;color:#F0EAD6;font-family:Georgia,serif;max-width:520px;margin:0 auto;padding:2rem">
  <h1 style="font-size:2rem;font-weight:300;color:#C9A84C;margin-bottom:0.25rem">CalmDaily</h1>
  <p style="color:#9A9080;font-size:0.8rem;margin-bottom:2rem">Your daily wellness ritual</p>
  <h2 style="font-size:1.5rem;font-weight:300;margin-bottom:1rem">Welcome, ${firstName} 👋</h2>
  <p style="color:#9A9080;line-height:1.8;margin-bottom:1rem">
    You've taken the first step towards a calmer, more mindful life.
    CalmDaily is here every day — for your mornings, your stressful moments,
    and your evenings.
  </p>
  <p style="color:#9A9080;line-height:1.8;margin-bottom:1.5rem">
    Here's what to do first:
  </p>
  <div style="background:#181818;border-left:2px solid #C9A84C;padding:1rem 1.25rem;border-radius:0 8px 8px 0;margin-bottom:1rem">
    <strong style="color:#C9A84C">1.</strong> <span style="color:#F0EAD6">Try a 5-minute breathing session</span><br/>
    <span style="color:#9A9080;font-size:0.85rem">The 4-7-8 technique is perfect for beginners.</span>
  </div>
  <div style="background:#181818;border-left:2px solid #C9A84C;padding:1rem 1.25rem;border-radius:0 8px 8px 0;margin-bottom:1rem">
    <strong style="color:#C9A84C">2.</strong> <span style="color:#F0EAD6">Set a daily reminder</span><br/>
    <span style="color:#9A9080;font-size:0.85rem">Users with reminders are 3x more consistent.</span>
  </div>
  <div style="background:#181818;border-left:2px solid #C9A84C;padding:1rem 1.25rem;border-radius:0 8px 8px 0;margin-bottom:2rem">
    <strong style="color:#C9A84C">3.</strong> <span style="color:#F0EAD6">Check in your mood every day</span><br/>
    <span style="color:#9A9080;font-size:0.85rem">Tracking mood for 7 days reveals powerful patterns.</span>
  </div>
  <a href="https://YOUR-USERNAME.github.io/calmdaily/pages/dashboard.html"
     style="display:inline-block;background:#C9A84C;color:#0E0E0E;padding:0.8rem 2rem;border-radius:50px;text-decoration:none;font-size:0.9rem;font-family:sans-serif;font-weight:500;margin-bottom:2rem">
    Open CalmDaily →
  </a>
  <p style="color:#5C5550;font-size:0.75rem;line-height:1.6">
    You're on the free plan. <a href="https://YOUR-USERNAME.github.io/calmdaily/pages/dashboard.html" style="color:#C9A84C">Upgrade to Premium</a> for unlimited sessions, 30+ sleep sounds, and smart reminders.<br/><br/>
    Questions? Reply to this email — we read every message.<br/>
    <a href="https://YOUR-USERNAME.github.io/calmdaily/pages/privacy.html" style="color:#9A9080">Privacy Policy</a> · 
    <a href="https://YOUR-USERNAME.github.io/calmdaily/pages/terms.html" style="color:#9A9080">Terms</a>
  </p>
</body>
</html>`,
      }),
    });

    const emailData = await emailRes.json();
    res.json({ success: true, id: emailData.id });
  } catch (err) {
    console.error('Welcome email error:', err);
    res.json({ success: false, error: err.message });
  }
});
